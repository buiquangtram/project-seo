Child theme tutorial:

This theme allows you to modify the Newspaper theme without editing the main theme.

As of now you can change the template (the files in the root of the theme http://screencast.com/t/AvdWkNcu ) and the modules

The modules are used in loops (on templates and in blocks to show content: http://screencast.com/t/WYiHW2XM ) . To see the list of all the modules go here: http://forum.tagdiv.com/modules-and-blocks/

To change module 1 for example copy it from the newspaper theme Newspaper/includes/modules/td_module_1.php to this child theme in includes/modules/td_module_1.php http://screencast.com/t/VvZvPWcN